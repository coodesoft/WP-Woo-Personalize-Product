<?php

if (!defined('WP_UNINSTALL_PLUGIN')) {
    //delete_option(‘mi_opcion’); 
    die;
}

?>
