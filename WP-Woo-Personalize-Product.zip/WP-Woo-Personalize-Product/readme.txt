El plugin será visible en aquellas páginas en las que se incluya con el siguiente shortcode: coode_WPP_tour
